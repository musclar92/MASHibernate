package source;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
public class Insurance {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int idInsurance;
    private double ammount;
    private LocalDate startTime;

    @ManyToOne
    private Person person;

    protected Insurance()
    {};

    public static Insurance createInsurance(Person person, double ammount, LocalDate startTime)
    {
        if(person.equals(null))
        {
            throw new RuntimeException("Can't create Insurance without Person");
        }
        Insurance insurance = new Insurance(person, ammount, startTime);
        return insurance;
    }

    private Insurance(Person person, double ammount, LocalDate startTime)
    {
        this.ammount = ammount;
        this.startTime = startTime;
        this.assignPerson(person);
    }

    public int getIdInsurance() {
        return idInsurance;
    }

    public void setIdInsurance(int idInsurance) {
        this.idInsurance = idInsurance;
    }

    public void removePerson()
    {
        throw new RuntimeException("Can't remove, this Insurance is assign to this Person" );
    }

    public void assignPerson(Person person){
        if(person.equals(null))
        {
            throw new RuntimeException("person can't be null");
        }else if(this.person == null)
        {
            this.person = person;
            person.addInsurance(this);
        }else
        {
            throw new RuntimeException("Can't assign this Insurance to another Person");
        }
    }

    public double getAmmount() {
        return ammount;
    }

    public void setAmmount(double ammount) {
        this.ammount = ammount;
    }

    public LocalDate getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDate startTime) {
        this.startTime = startTime;
    }




}
