package source;

import java.time.LocalDate;

/**
 * Interface for Employee part
 */
public interface IEmployee {

    public boolean isStillEmployee();
    public void endContract(LocalDate endDate);
    public void endContract();
    public void addRaise(double howMany);
  //  public static void giveRaiseToAllEmployess(double howMany);
}