package source;

import javax.persistence.*;
import javax.persistence.criteria.CriteriaBuilder;
import java.time.LocalDate;
import java.time.Period;
import java.util.*;

/**
 *
 * @author Tomasz.ORZEL
 */

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Person {          //Klasa abstrakcyjna

    @Id @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int idPerson;
    private String firstName = "Player";
    private String lastName = "Player";
    private LocalDate birthDate;
    @JoinColumn(unique = true)
    private String docNumber;

    private static HashSet<Insurance> globalInsuraneList = new HashSet<Insurance>();

    private static HashSet<String> globalDocNumbersList = new HashSet<String>();

  //  @OneToMany
  //  private ArrayList<PersonEquip>  personEquips = new ArrayList<PersonEquip>();

 //   @ManyToMany(cascade =  CascadeType.ALL, targetEntity = Equipment.class)
 //   private Collection<Equipment> assignEquipment = new ArrayList<Equipment>();
   @OneToMany(cascade = CascadeType.ALL, targetEntity = Insurance.class)
    private Set<Insurance> insuranceList = new HashSet<Insurance>();


    public Person() {};
    /**
     * Konstructor dla Person
     * @param idPerson
     * @param firstName
     * @param lastName
     * @param birthDate
     * @param docNumber
     */

    public Person(int idPerson, String firstName, String lastName, LocalDate birthDate, String docNumber)
    {
        this.idPerson = idPerson;
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthDate = birthDate;
        this.setDocNumber(docNumber);
    }

    public Person(String firstName, String lastName, LocalDate birthDate, String docNumber)
    {
        this.firstName = firstName;
        this.birthDate = birthDate;
        this.lastName = lastName;
        this.setDocNumber(docNumber);
    }


    public Set<Insurance> getInsuranceList() {
        return Collections.unmodifiableSet(insuranceList);
    }

    public void setInsuranceList(Set<Insurance> insuranceList) {
        this.insuranceList = insuranceList;
    }

    public void addInsurance(Insurance insurance)
    {
        if(!this.getInsuranceList().contains(insurance))
        {
            if(globalInsuraneList.contains(insurance))
            {
                throw new RuntimeException("This Insurance is already assigned");
            }else
            {
                globalInsuraneList.add(insurance);
                insuranceList.add(insurance);
            }

        }
    }


    /**
     * Sprawdzenie wieku Osoby
     * @return wiek
     */
    public int checkAge()
    {
        if (birthDate != null) {
            return Period.between(birthDate, LocalDate.now()).getYears();
        } else {
            return 0;
        }
    }

    /**
     * Pobranie id osoby
     * @return
     */
    public int getIdPerson() {
        return idPerson;
    }

    /**
     * Pobranie imienia od osoby
     * @return
     */
    public String getFirstName(){return this.firstName;}

    /**
     * Pobranie nazwiska
     * @return
     */
    public String getLastName(){return this.lastName;}

    /**
     * Pobranie nr. dokumentu od osoby
     * @return
     */
    public String getDocNumber(){return this.docNumber;}

    /**
     * Pobranie daty urodzenia
     * @return
     */
    public LocalDate getBirthDate(){return this.birthDate;}

    /**
     * Ustawienie id osobie
     * @param idPerson
     */
    public void setIdPerson(int idPerson) {
        this.idPerson = idPerson;
    }

    /**
     * Ustawienie Imienia
     * @param firstName
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Ustawienie nazwiska
     * @param lastName
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Ustawienie daty urodzenia
     * @param birthDate
     */
    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    /**
     * Ustawienie nr. dokumentu
     * @param docNumber
     */
    public void setDocNumber(String docNumber) {
        if(globalDocNumbersList.contains(docNumber))
        {
            System.out.println("User with doc number like this already exist");
        }else
        {
            this.docNumber = docNumber;
        }

    }

}
