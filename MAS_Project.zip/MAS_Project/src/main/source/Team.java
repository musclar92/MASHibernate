package source;

//import database.TeamDAO;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.*;

/**
 * @author Tomasz.ORZEL
 */

@Entity
public class Team {

    @Id
    @GeneratedValue
    private int TeamID;
    private String ligueName;
    private int ligue;
    private int playersInTeam = 0;
    private static int maxPlayersInTeam = 25;

    @OneToOne(cascade = CascadeType.ALL)
    private Player capitan;

    @OneToMany(mappedBy = "currentlyTeam", cascade = CascadeType.ALL)
    private Set<Player> currentylyInTeam = new HashSet<Player>();

    @OneToMany(cascade = CascadeType.ALL)
    private List<PlayerInTeam> inTeamList = new ArrayList<PlayerInTeam>();

    @OneToMany(cascade = CascadeType.ALL)
    private Map<String, Coach> coachTeam = new TreeMap<String, Coach>();

    @OneToMany
    private List<Match> matchList = new ArrayList<Match>();

    public List<PlayerInTeam> getInTeamList() {
        return Collections.unmodifiableList(inTeamList);
    }

    public Team() {}

    /**
     * Konstruktor klasy Team
     * @param TeamID
     * @param ligueName
     * @param ligue
     */
    public Team(int TeamID, String ligueName, int ligue)
    {
        this.setTeamID(TeamID);
        this.setLigueName(ligueName);
        this.setLigue(ligue);
    }

    /**
     * Konstruktor klasy Team z kapitanem
     * @param TeamID
     * @param ligueName
     * @param ligue
     * @param capitan
     */
    public Team(int TeamID, String ligueName, int ligue, Player capitan)
    {
        this.setTeamID(TeamID);
        this.setLigueName(ligueName);
        this.setLigue(ligue);
        this.setNewCapitan(capitan);
    }

    public Team(String ligueName, int ligue)
    {
        this.setLigueName(ligueName);
        this.setLigue(ligue);
    }


    public void addPlayerInTeam(Player player){
        if(player.equals(null))
        {
            throw new RuntimeException("Player can't be null");
        }
        else if(currentylyInTeam.contains(player))
        {
            System.out.println("This player already belong to this team");
        }
        else if(currentylyInTeam.size() == maxPlayersInTeam)
        {
            System.out.println("Too much players in this Team");
        }else if(getCoachTeam().containsValue(player))
        {
            System.out.println("This player can't belong to this team because they train it");
        }else
        {
            this.currentylyInTeam.add(player);
            PlayerInTeam newPlayerInTeam = new PlayerInTeam(LocalDate.now(), player, this);
            this.inTeamList.add(newPlayerInTeam);
            player.setPlayerInTeam(this, newPlayerInTeam);
        }
    }

    public void addPlayerInTeam(Player player, PlayerInTeam playerInTeam){  //TODO
        if(player.equals(null) && playerInTeam.equals(null))
        {
            throw new RuntimeException("Player and PlayerInTeam can't be null");
        }
        else if(currentylyInTeam.contains(player))
        {
            System.out.println("This player already belong to this team");
        }
        else if(currentylyInTeam.size() == maxPlayersInTeam)
        {
            System.out.println("Too much players in this Team");
        }else if(getCoachTeam().containsValue(player))
        {
            System.out.println("This player can't belong to this team because they train it");
        }else
        {
            this.currentylyInTeam.add(player);
            this.inTeamList.add(playerInTeam);
        }
    }

    public void removePlayerInTeam(Player player)
    {
        if(player.equals(null))
        {
            throw new RuntimeException("Player can't be null");
        }else if(!getCurrentylyInTeam().contains(player))
        {
            System.out.println("This player not belong to this Team");
        }else
        {
            currentylyInTeam.remove(player);
            player.removePlayerInTeam();
            if(getCapitan() == player)
            {
                System.out.println("This team don't have capitan anymore");
                removeCapitan();
            }
        }

    }

    public void setTeamID(int teamID) {
        TeamID = teamID;
    }

    public void setInTeamList(List<PlayerInTeam> inTeamList) {
        this.inTeamList = inTeamList;
    }

    public void setCoachTeam(Map<String, Coach> coachTeam) {
        this.coachTeam = coachTeam;
    }

    public List<Match> getMatchList() {
        return matchList;
    }

    public void setMatchList(List<Match> matchList) {
        this.matchList = matchList;
    }

    public Set<Player> getCurrentylyInTeam() {
        return currentylyInTeam;
    }

    public void setCurrentylyInTeam(Set<Player> currentylyInTeam) {
        this.currentylyInTeam = currentylyInTeam;
    }

    public static int getMaxPlayersInTeam() {
        return maxPlayersInTeam;
    }

    public static void setMaxPlayersInTeam(int maxPlayersInTeam) {
        Team.maxPlayersInTeam = maxPlayersInTeam;
    }

    public void setLigue(int ligue) {
        this.ligue = ligue;
    }

    public int getPlayersInTeam() {
        return playersInTeam;
    }

    public void setPlayersInTeam(int playersInTeam) {
        this.playersInTeam = playersInTeam;
    }

    public void setCapitan(Player capitan) {
        if(capitan == null)
        {
            throw new RuntimeException("Capitan can't be null");
        }else
        {
            setNewCapitan(capitan);
        }

    }

    public Map<String, Employee> getCoachTeam() {
        return Collections.unmodifiableMap(coachTeam);
    }

    public void addCoachTeam(Coach coach)
    {
        if(coach.equals(null))
        {
            throw new RuntimeException("Coach can't be null");
        }else if(coachTeam.containsKey(coach.getLicense()))
        {
            System.out.println("coach already in team!");
        }else if(getCurrentylyInTeam().contains(coach))
        {
            System.out.println("Coach belong to this team! Can't train himself!");
        }else
        {
            coachTeam.put(coach.getLicense(), coach);
            coach.setTrainsTeam(this);
        }
    }

    public void removeCoachTeam(Coach coach)
    {
        if(coachTeam.size()<=1)
        {
            throw new RuntimeException("Can't remove last coach!");
        }else if(!coachTeam.containsKey(coach.getLicense()))
        {
            System.out.println("Coach is not a part of CoachTeam");
        }else
        {
            coachTeam.remove(coach.getLicense());
            coach.removeFromTeam();
        }
    }

    /**
     * Ustawienie nowego kapitana druzyny
     * @param player - gracz ktory ma byc ustawiony jako kapitan
     */

    public void  setNewCapitan(Player player) //zmieniona asocjacja na 1 do 1
    {
        if(player.equals(null))
        {
            throw new RuntimeException("Player can't be null");
        }else if(capitan == player)
        {
            System.out.println("This capitan already set!");
        }else if(currentylyInTeam.contains(player)) {
            if(capitan!=null)
            {
                this.removeCapitan();
            }
            this.capitan = player;
            player.setCapitan(this);
        }else {
            System.out.println("Player not belong to this team!");

        }
    }
    /**
     * Usuniecie kapitana z druzyny
     */

    public void removeCapitan()
    {
        if(capitan == null)
        {
            System.out.println("Team don't have capitan anymore");
        }else{
            Player player = getCapitan();
            capitan = null;
            player.removeFromCapitanFunction();
        }
    }
    private void promotion(String ligueName)
    {
        this.ligueName = ligueName;
        if(this.ligue==1)
        {
            System.out.println("Brak możliwości awansu! Najwyzsza klasa rozgrywkowa");
        }else {
            this.ligue--;
            System.out.println("AWANS! Nowa liga o nazwie: " + ligueName);
        }
    }

    /**
     * Spadek z aktualnej ligi
     * @param ligueName nazwa nowej ligi
     */
    private void decrase(String ligueName)
    {
        this.ligueName = ligueName;
        this.ligue++;
        System.out.println("SPADEK! Nowa liga o nazwie: "+ ligueName);
    }

    /**
     * Przekaż nazwe ligi
     * @return
     */
    public String showLigueName()
    {
        return this.ligueName;
    }

    /**
     * Przekaz numer ligi
     * @return
     */
    public String showLigueNumber() {
        return Integer.toString(this.ligue);
    }

    /**
     * Pobierz id druzyny
     * @return
     */
    public int getTeamID(){
        return this.TeamID;
    }

    /**
     * Pobierz numer ligi
     * @return
     */
    public int getLigue(){
        return this.ligue;
    }

    /**
     * Wypisz nazwe ligi
     * @return
     */
    public String toString(){
        return " "+ligueName+" "+ligue;
    }

    /**
     * Przekaz kapitana druzyny
     * @return
     */
    public Player getCapitan() {
        return capitan;
    }

    /**
     * Pobierz nazwe ligi w ktorej gra druzyna
     * @return
     */
    public String getLigueName() {
        return ligueName;
    }

    /**
     * Ustaw nazwe ligi w ktorej gra druzyna
     * @param ligueName
     */
    public void setLigueName(String ligueName) {
        this.ligueName = ligueName;
    }

    public void removeOnePlayerFromTeam(){
        playersInTeam--;
    }

}
