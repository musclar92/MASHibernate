package source;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
public class PlayerInTeam {

    @Id
    @GeneratedValue
    private int playerInTeamID;
    private LocalDate startDate;
    private LocalDate endDate = null;

    @ManyToOne
    private Player player;

    @ManyToOne
    private Team team;

    public PlayerInTeam(LocalDate startDate, LocalDate endDate, Player player, Team team) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.player = player;
        this.team = team;
    }

    public PlayerInTeam(LocalDate startDate, Player player, Team team) {
        this.startDate = startDate;
        this.endDate = null;
        this.player = player;
        this.team = team;
    }

    public PlayerInTeam() {
    }

    public int getPlayerInTeamID() {
        return playerInTeamID;
    }

    public void setPlayerInTeamID(int playerInTeamID) {
        this.playerInTeamID = playerInTeamID;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }
}
