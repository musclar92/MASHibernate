package source;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

enum TrainingType {tactic, strength, cardio, freak}

@Entity
public class Training {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int trainingID;
    private LocalDate trainingDate;
    private TrainingType trainingType;
    private LocalTime trainingHour;

    @ManyToOne
    private Localization trainingLocalization;

    @ManyToOne
    private Team trainingTeam;

    @ManyToOne
    private Coach organizator;


    public Training(LocalDate trainingDate, TrainingType trainingType, LocalTime trainingHour) {
        this.trainingDate = trainingDate;
        this.trainingType = trainingType;
        this.trainingHour = trainingHour;
    }

    public Training(LocalDate trainingDate, TrainingType trainingType, Localization trainingLocalization, Team trainingTeam, Coach organizator) {
        this.trainingDate = trainingDate;
        this.trainingType = trainingType;
        this.trainingLocalization = trainingLocalization;
        this.trainingTeam = trainingTeam;
        this.organizator = organizator;
    }

    public Training() {
    }

    public LocalDate getTrainingDate() {
        return trainingDate;
    }

    public void setTrainingDate(LocalDate trainingDate) {
        this.trainingDate = trainingDate;
    }

    public TrainingType getTrainingType() {
        return trainingType;
    }

    public void setTrainingType(TrainingType trainingType) {
        this.trainingType = trainingType;
    }

    public int getTrainingID() {
        return trainingID;
    }

    public void setTrainingID(int trainingID) {
        this.trainingID = trainingID;
    }

    public Localization getTrainingLocalization() {
        return trainingLocalization;
    }

    public void setTrainingLocalization(Localization trainingLocalization) {
        if(this.getTrainingDate()== null || this.getTrainingHour()== null || this.getTrainingTeam()== null)
        {
            new Exception("Date, hour and Team can't be null");
        }else if(trainingLocalization.checkIsAvailable(this.getTrainingDate(), this.getTrainingHour()))
        {
            trainingLocalization.addLocReservationForTraining(this.getTrainingDate(),this.getTrainingHour(),this.getTrainingTeam(),this);
            this.trainingLocalization = trainingLocalization;
        }else
        {
            System.out.println("This date is already taken, chose anotherone!");
        }
    }

    public Team getTrainingTeam() {
        return trainingTeam;
    }

    public void setTrainingTeam(Team trainingTeam) {
        this.trainingTeam = trainingTeam;
    }

    public Coach getOrganizator() {
        return organizator;
    }

    public void setOrganizator(Coach organizator) {
        this.organizator = organizator;
    }

    public LocalTime getTrainingHour() {
        return trainingHour;
    }

    public void setTrainingHour(LocalTime trainingHour) {
        this.trainingHour = trainingHour;
    }
}
