package source;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Enum tworzacy rodzaje zawodnikow
 */
enum PlayerType {AdultPlayer, YouthPlayer};


/**
 * @author Tomasz.ORZEL
 */

@Entity
public class Player extends Person implements IEmployee{

    private static int minStats = 0;     //minimalna dopuszczana wartosc
    private static int maxStats = 100;   //maksymalna dopuszczana wartosc

    private char betterLeg = 'R';       //L or R
    private int speed = 50,             //statystyka szybkosci
                technique = 50,         //statystyka techniki
                strength = 50;          //statystyka sily
    //private double stat;                //wyliczana srednia statystyka
    private PlayerPosition position;    //Pozycja

    @OneToOne(optional = true, cascade = CascadeType.ALL)
    private Team capitanInTeam = null;

    @ManyToOne(optional = true, cascade = CascadeType.ALL)
    private Team currentlyTeam;

    @OneToMany(cascade = CascadeType.ALL)
    private List<PlayerInTeam> playerInTeam = new ArrayList<PlayerInTeam>();

    private PlayerType playerType = PlayerType.YouthPlayer; //disjoin

    //youthPlayer
    private static int ageLimit = 16;

    //Only for YouthPlayer
    @Embedded
    private Parent parent;

    //Only for AdultPlayers
    private Double salary = null;
    private LocalDate employmentDate = null;
    private LocalDate contractTo = null;
    private LocalDate releaseDate = null;
    private static double riseMax = Employee.getRiseMax();
    private String jobTitle = "Zawodnik";

    public Player() {
    }


    public static void setMinStats(int minStats) {
        Player.minStats = minStats;
    }

    public static void setMaxStats(int maxStats) {
        Player.maxStats = maxStats;
    }

    /*public void setStat(double stat) {
        this.stat = stat;
    }*/

    public Team getCapitanInTeam() {
        return capitanInTeam;
    }

    public void setCapitanInTeam(Team capitanInTeam) {
        if(capitanInTeam == null)
        {
            throw new RuntimeException("New Team can't be null");
        }else if(this.capitanInTeam == null)
        {
            this.capitanInTeam = capitanInTeam;
            capitanInTeam.setNewCapitan(this);
        }else
        {
            this.capitanInTeam.removeCapitan();
            this.capitanInTeam = null;
        }
    }

    public void setPlayerType(PlayerType playerType) {
        this.playerType = playerType;
    }

    public Parent getParent() {

        if(this.playerType.equals(PlayerType.AdultPlayer))
        {
            System.out.println("Adult Player's don't have parents");
            return null;
        }else
        {
            return this.parent;
        }
    }

    public void setParent(Parent parent) {
        if(this.playerType.equals(PlayerType.AdultPlayer))
        {
            System.out.println("Adult Player's don't have parents");
        }else
        {
            if(this.parent == null)
            {
                this.parent = parent;
            }else
            {
                this.removeParent();
                this.parent = parent;
            }

        }
    }

    //AdultPlayer
    //private Employee employee; //TODO only for AdultPlayers

    /**
     * Konstruktor klasy Player
     * @param PersoID
     * @param firstName
     * @param lastName
     * @param birthDate
     * @param docNumber
     * @param betterLeg
     * @param speed
     * @param technique
     * @param strength
     * @param position
     */
    public Player(int PersoID, String firstName, String lastName, LocalDate birthDate, String docNumber,
                  char betterLeg, int speed, int technique, int strength, PlayerPosition position) {
        super(PersoID, firstName, lastName, birthDate, docNumber);
        this.setBetterLeg(betterLeg);
        this.setPosition(position);
        this.setSpeed(speed);
        this.setTechnique(technique);
        this.setStrength(strength);
        this.setPlayerType();
        //this.countStat();
    }

    public Player(String firstName, String lastName, LocalDate birthDate, String docNumber,
                  char betterLeg, int speed, int technique, int strength, PlayerPosition position) {
        super(firstName, lastName, birthDate, docNumber);
        this.setBetterLeg(betterLeg);
        this.setPosition(position);
        this.setSpeed(speed);
        this.setTechnique(technique);
        this.setStrength(strength);
        this.setPlayerType();
    }

    /**
     * Konstruktor klasy Player, tylko podstawowe dane z Person
     * @param PersoID
     * @param firstName
     * @param lastName
     * @param birthDate
     * @param docNumber
     */
    public Player(int PersoID, String firstName, String lastName, LocalDate birthDate, String docNumber)
    {
        super(PersoID, firstName, lastName, birthDate, docNumber);
        setPlayerType();
    }

    /**
     * Ustawienie typu gracza, Młodzieżowec czy Dorosły
     */
    public void setPlayerType()
    {
        if(checkAge()< ageLimit) {
            this.playerType= PlayerType.YouthPlayer;
        }
        else {
            this.playerType = PlayerType.AdultPlayer;
        }
    }

    /**
     * Zmiana typu gracza, z młodzieżowca na dorosłego, w przypadku gdy spełnia warunki
     */
    public void changePlayerType()
    {
        if(checkAge()< getAgeLimit()) {
            if(getPlayerType().equals(PlayerType.YouthPlayer))
            {
                System.out.println("This is still youth Player");
            }
            else
            {
                System.out.println("Can't change from Adult to Youth"); //nie ma to sensu ale wole sie zabezpieczyc
            }
        }
        else {
            if(getPlayerType().equals(PlayerType.AdultPlayer))
            {
                throw new RuntimeException("This is still Adult Player");
            }else
            {
                this.playerType = PlayerType.AdultPlayer;
                this.removeParent();
                System.out.println("Now this is AdultPlayer!");
            }
        }
    }

    /**
     * Pobranie rodzaju zawodnika
     * @return
     */
    public PlayerType getPlayerType()
    {
        return this.playerType;
    }

    public List<PlayerInTeam> getPlayerInTeam() {
        return playerInTeam;
    }

    public Team getCurrentlyTeam()
    {
        return this.currentlyTeam;
    }

    public void setCurrentlyTeam(Team team)
    {
        this.currentlyTeam = team;
    }

    public void setPlayerInTeam(Team team)
    {
        if(team.equals(null)) {
            throw new RuntimeException("Team can't be null");
        }else if(team.getPlayersInTeam() == team.getMaxPlayersInTeam()) {
            throw new RuntimeException("Too much players in This Team");
        }else if(team.getCoachTeam().containsValue(this))
        {
            System.out.println("Player is already Coach in this team! Can't be also a Player");
        }else
        {
            removePlayerInTeam();
            PlayerInTeam newPlayerInTeam = new PlayerInTeam(LocalDate.now(), this, team);
            this.playerInTeam.add(newPlayerInTeam);
            setCurrentlyTeam(team);
            team.addPlayerInTeam(this, newPlayerInTeam);
        }
    }

    public void setPlayerInTeam(Team team, PlayerInTeam playerInTeam) //TODO
    {
        if(team.equals(null)) {
            throw new RuntimeException("Team can't be null");
        }else if(team.getPlayersInTeam() == team.getMaxPlayersInTeam()) {
            throw new RuntimeException("Too much players in This Team");
        }else if(currentlyTeam == team)
        {
            System.out.println("Player already in this team");
        }else
        {
            removePlayerInTeam();
            this.playerInTeam.add(playerInTeam);
            setCurrentlyTeam(team);
        }
    }

    public void removePlayerInTeam()
    {
        if(getCurrentlyTeam() != null)
        {
            Team team = this.getCurrentlyTeam();
            this.setCurrentlyTeam(null);
            team.removePlayerInTeam(this);

            for(int i=0; i<playerInTeam.size(); i++) {
                if (playerInTeam.get(i).getEndDate() == null) {
                    playerInTeam.get(i).setEndDate(LocalDate.now());
                }
            }

            if(this.getCapitanInTeam() == null)
            {
                this.removeFromCapitanFunction();
            }
        }

    }


    /**
     * Zmiana statystyki szykosci
     * @param newSpeed
     */
    public void setSpeed(int newSpeed) {
        if (newSpeed >= minStats && newSpeed <= maxStats) {
            this.speed = newSpeed;
            countStat();
        } else {
            System.out.println("Speed stat, not changed!!! Chose right number between " + minStats + " - " + maxStats);
        }
    }

    /**
     * Zmiana statystyki techniki
     * @param newTechnique
     */
    public void setTechnique(int newTechnique) {
        if (newTechnique >= minStats && newTechnique <= maxStats) {
            this.technique = newTechnique;
            countStat();
        } else {
            System.out.println("Stat not changed!!! Chose right number between " + minStats + " - " + maxStats);
        }
    }

    /**
     * Zmiana statystyki sily
     * @param newStrength
     */
    public void setStrength(int newStrength) {
        if (newStrength >= minStats && newStrength <= maxStats) {
            this.strength = newStrength;
            countStat();
        } else {
            System.out.println("Speed stat, not changed!!! Chose right number between " + minStats + " - " + maxStats);
        }
    }

    /**
     * Zmiana domyslnej pozycji zawodnika
     * @param newPosition
     */
    public void setPosition(PlayerPosition newPosition)
    {
        this.position = newPosition;
    }

    /**
     * Zmiana lepszej nogi zawodnika
     * @param betterLeg
     */
    public void setBetterLeg(char betterLeg) {
        this.betterLeg = betterLeg;
    }

    /**
     * Wyliczenie statystyki ogolnej z 3 pozostalych statystyk
     * @return
     */
    public double countStat() {
        return (this.getTechnique() + this.getSpeed() + this.getStrength()) / 3;
    }

    /**
     * Pobranie informacji o lepszej nodze
     * @return
     */
    public char getBetterLeg() {
        return this.betterLeg;
    }

    /**
     * Pobranie informacji o statystyce sily
     * @return
     */
    public int getStrength() {
        return this.strength;
    }

    /**
     * Pobranie statystyki techniki
     * @return
     */
    public int getTechnique() {
        return this.technique;
    }

    /**
     * Pobranie statystyki szybkosci
     * @return
     */
    public int getSpeed() {
        return this.speed;
    }

    /**
     * Pobranie aktualnej pozycji zawodnika
     * @return
     */
    public PlayerPosition getPosition() {
        return this.position;
    }


    public static int getMinStats() {
        return minStats;
    }



    public static int getMaxStats() {
        return maxStats;
    }

    /**
     * Usuwanie zawodnika z funkcji kapitana
     */
    public void removeFromCapitanFunction()        //asocjacja 1 do 1
    {
        if(capitanInTeam == null)
        {
            System.out.println("There is now capitan in this team!");
        }else
        {
            Team team = getCapitanInTeam();
            capitanInTeam=null;
            team.removeCapitan();
        }
    }

    /**
     * Ustanawianie zawodnika kapitanem w danej druzynie
     * @param team
     */
    public void setCapitan(Team team){
        if(team.equals(null))
        {
            throw new RuntimeException("Team can't be null");
        }else if(capitanInTeam == null)
        {
            this.capitanInTeam = team;
            team.setNewCapitan(this);
        }else
        {
            team.getCapitan().removeFromCapitanFunction();
            this.capitanInTeam = team;
            team.setNewCapitan(this);
        }


    }

    private void removeParent()
    {
        if(playerType.equals(PlayerType.AdultPlayer))
        {
            throw new RuntimeException("Adult player don't have Parents");  //Czyli opiekunow
        }else
        {
            this.parent = null;
        }
    }

    /**
     * Przekazanie informacji o wieku.
     * @return
     */
    public static int getAgeLimit() {
        return ageLimit;
    }

    /**
     * Zmiana limitu lat wymaganego do przejscia na zawodnika doroslego
     * @param ageLimit
     */
    public static void setAgeLimit(int ageLimit) {
        Player.ageLimit = ageLimit;    //nie powinno byc uywane
    }

    /**
     * Sprawzenie czy zawodnik jest zatrudniony
     * @return
     */
    @Override
    public boolean isStillEmployee() {
        if(playerType.equals(PlayerType.YouthPlayer))
        {
            throw new RuntimeException("Youth Player can't be employee");
        }else
        {
            if(releaseDate == null)
            {
                return true;
            }else
            {
                return false;
            }
        }
    }

    /**
     * Zakonczenie kontraktu - jedynie w przypadku zawodnikow bedacych zatrudnionymi
     * @param endDate
     */
    @Override
    public void endContract(LocalDate endDate) {
        if(playerType.equals(PlayerType.YouthPlayer))
        {
            throw new RuntimeException("Youth Player can't be employee, and do't have contract");
        }else
        {
            this.setReleaseDate(endDate);
        }
    }

    @Override
    public void endContract() {
        if(this.playerType.equals(PlayerType.AdultPlayer))
        {
            this.setReleaseDate(LocalDate.now());
        }
        else
        {
            System.out.println("Only for Adult Players");
        }
    }

    /**
     * Mozliwosc dania podwyzki
     * @param howMany
     */

    @Override
    public void addRaise(double howMany) {
        if(playerType.equals(PlayerType.YouthPlayer))
        {
            throw new RuntimeException("Youth Player can't be employee, and can't get raise");
        }else
        {
            salary+=howMany;
        }
    }

    //@Override
    public void addAllRaise(double howMany) {
        //TODO all Raise all AdultPlayers
    }

    public Double getSalary() {
        if(this.playerType.equals(PlayerType.AdultPlayer))
        {
            return salary;
        }
        else
        {
            System.out.println("Only for Adult Players");
            return null;
        }
    }

    public void setSalary(Double salary) {

        if(this.playerType.equals(PlayerType.AdultPlayer))
        {
            this.salary = salary;
        }
        else
        {
            System.out.println("Only for Adult Players");
        }
    }

    public LocalDate getEmploymentDate() {
        if(this.playerType.equals(PlayerType.AdultPlayer))
        {
            return employmentDate;
        }
        else
        {
            System.out.println("Only for Adult Players");
            return null;
        }
    }

    public void setEmploymentDate(LocalDate employmentDate) {
        if(this.playerType.equals(PlayerType.AdultPlayer))
        {
            this.employmentDate = employmentDate;
        }
        else
        {
            System.out.println("Only for Adult Players");
        }

    }

    public LocalDate getContractTo() {
        if(this.playerType.equals(PlayerType.AdultPlayer))
        {
            return contractTo;
        }
        else
        {
            System.out.println("Only for Adult Players");
            return null;
        }

    }

    public void setContractTo(LocalDate contractTo) {
        if(this.playerType.equals(PlayerType.AdultPlayer))
        {
            this.contractTo = contractTo;
        }
        else
        {
            System.out.println("Only for Adult Players");
        }

    }

    public LocalDate getReleaseDate() {
        if(this.playerType.equals(PlayerType.AdultPlayer))
        {
            return releaseDate;
        }
        else
        {
            System.out.println("Only for Adult Players");
            return null;
        }

    }

    public void setReleaseDate(LocalDate releaseDate) {
        if(this.playerType.equals(PlayerType.AdultPlayer))
        {
            this.releaseDate = releaseDate;
        }
        else
        {
            System.out.println("Only for Adult Players");
        }

    }

    public static double getRiseMax() {
        return riseMax;
    }

    public static void setRiseMax(double riseMax) {
        Player.riseMax = riseMax;
    }

    public String getJobTitle() {
        if(this.playerType.equals(PlayerType.AdultPlayer))
        {
            return jobTitle;
        }
        else
        {
            System.out.println("Only for Adult Players");
            return null;
        }

    }

    public void setJobTitle(String jobTitle) {
        if(this.playerType.equals(PlayerType.AdultPlayer))
        {
            this.jobTitle = jobTitle;
        }
        else
        {
            System.out.println("Only for Adult Players");
        }

    }
}

/**
 * Klasa reprezentujaca rodzicow
 */
@Embeddable
class Parent{

    @Column(name = "parent_First_Name")
    private String firstName;
    @Column(name = "parent_Last_Name")
    private String lastName;
    @Column(name = "parent_Email_Adress")
    private String emailAdress;
    @Column (name ="parent_Telephone_Number")
    private long telephoneNumber;

    public Parent(String firstName, String lastName, String emailAdress, long telephoneNumber)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailAdress = emailAdress;
        this.telephoneNumber = telephoneNumber;
    }

    public  Parent() {
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Pobierz informacje o adresie mailowym rodzica
     * @return
     */
    public String getEmailAdress() {
        return emailAdress;
    }

    /**
     * Ustaw adres mailowy rodzica
     * @param emailAdress
     */
    public void setEmailAdress(String emailAdress) {
        this.emailAdress = emailAdress;
    }

    /**
     * Pobierz numer telefonu rodzica
     * @return
     */
    public long getTelephoneNumber() {
        return telephoneNumber;
    }

    /**
     * Ustaw numer telefonu rodzica
     * @param telephoneNumber
     */
    public void setTelephoneNumber(long telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }



}