package source;

import org.hibernate.annotations.GeneratorType;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

@Entity
public class LocalizationReservation {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int locRezID;
    private LocalDate locRezDay;
    private Team[] reserwedBy;                      //TODO czy nie lepiej trzymać TeamID?
    private static int reservationHours = 24;


    public LocalizationReservation(LocalDate locRezDay) {
        this.locRezDay = locRezDay;
        generateReservedTable();
    }

    public LocalizationReservation(){};

    public void assignRezervation(LocalTime rezTime, Team team)
    {
        if(checkIsAvailable(rezTime))        //Wstepny warunek Kazda rezerwacja = 2h;
        {
            int hourToCheck = rezTime.getHour();
            reserwedBy[hourToCheck] = team;
            reserwedBy[hourToCheck+1] = team;
        }else
        {
            new Exception("This hour is not available");
        }
    }

    public boolean checkIsAvailable(LocalTime rezTime)      //Wstepny warunek, każda rezerwacja = 2h;
    {
        int hourToCheck = rezTime.getHour();
        if(reserwedBy[hourToCheck] == null && reserwedBy[hourToCheck+1] == null)
        {
            return true;
        }else
        {
            return false;
        }
    }

    private void generateReservedTable()
    {
        reserwedBy = new Team[24];

        for(int i=0; i<24; i++)
        {
            reserwedBy[i] = null;
        }
    }

    public LocalDate getLocRezDay() {
        return locRezDay;
    }

    public void setLocRezDay(LocalDate locRezDay) {
        this.locRezDay = locRezDay;
    }

    public Team[] getReserwedBy() {
        return reserwedBy;
    }

    public void setReserwedBy(Team[] reserwedBy) {
        this.reserwedBy = reserwedBy;
    }

    public static int getReservationHours() {
        return reservationHours;
    }

    public static void setReservationHours(int reservationHours) {
        LocalizationReservation.reservationHours = reservationHours;
    }

    public int getLocRezID() {
        return locRezID;
    }

    public void setLocRezID(int locRezID) {
        this.locRezID = locRezID;
    }


}
