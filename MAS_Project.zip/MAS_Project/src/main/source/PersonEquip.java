package source;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;



public class PersonEquip {

   private static DateTimeFormatter dateFormatDay = DateTimeFormatter.ofPattern("dd.MM.yyyy");


    private int personEquipID;
    private LocalDate transferDate;
    private LocalDate returnDate;
    private boolean condition;

    //@ManyToOne
    private Person assignPerson;
    //@ManyToOne
    private Equipment assignEquip;

    public PersonEquip()
    {
    }

    public PersonEquip(LocalDate transferDate, boolean condition) {
        this.transferDate = transferDate;
        this.condition = condition;
    }

    public int getPersonEquipID() {
        return personEquipID;
    }

    public void setPersonEquipID(int personEquipID) {
        this.personEquipID = personEquipID;
    }

    public LocalDate getTransferDate() {
        return transferDate;
    }

    public void setTransferDate(LocalDate transferDate) {
        this.transferDate = transferDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public boolean isCondition() {
        return condition;
    }

    public void setCondition(boolean condition) {
        this.condition = condition;
    }

    public Person getAssignPerson() {
        return assignPerson;
    }

   /* public void removeAssignetPerson() {
        if (assignPerson.equals(null)) {
            throw new RuntimeException("Person not assigned");
        }else{
            Person assPer;
            assPer = assignPerson;
            assignPerson = null;
            assPer.removePersonEquip(this);
        }
    }

    public void setAssignPerson(Person assignPerson) {
        if(assignPerson.equals(null))
        {
            throw new RuntimeException("assignPerson can't be null");
        }else if(assignPerson.equals(assignPerson))
        {
            throw new RuntimeException("Assignperson already assigned");
        }else
        {
            removeAssignetPerson();
            this.assignPerson = assignPerson;
        }

    }

    public Equipment getAssignEquip() {
        return assignEquip;
    }


    public void setAssignEquip(Equipment assignEquip) {
        if(assignEquip.equals(null))
        {
            throw new RuntimeException("assignEquip can't be null");
        }else if(assignEquip.equals(assignEquip))
        {
            throw new RuntimeException("Assignperson already assigned");
        }else
        {
            removeAssignetPerson();
            this.assignEquip = assignEquip;
        }
    }

    public void removeAssignetEqip() {
        if (assignEquip.equals(null)) {
            throw new RuntimeException("Equip not assigned");
        }else{
            Equipment assEq;
            assEq = assignEquip;
            assignPerson = null;
            assEq.removePersonEquip(this);
        }
    }

    */
}
