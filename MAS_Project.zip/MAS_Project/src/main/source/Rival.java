package source;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Entity
public class Rival {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int rivalId;
    private String clubName;
    private String teamName;
    private String coachName;
    private int ligue;

    @OneToMany
    private List<Match> match = new ArrayList<Match>();

    public Rival(){};

    public Rival(String clubName, String teamName, String coachName, int ligue) {
        this.clubName = clubName;
        this.teamName = teamName;
        this.coachName = coachName;
        this.ligue = ligue;
    }

    public int getRivalId() {
        return rivalId;
    }

    public void setRivalId(int rivalId) {
        this.rivalId = rivalId;
    }

    public List<Match> getMatch() {
        return Collections.unmodifiableList(match);
    }

    public void setMatch(List<Match> match) {
        this.match = match;
    }

    public void addMatch(Match match)
    {
        this.match.add(match);
    }

    public void removeMatch(Match match)
    {
        this.match.remove(match);
    }

    public String getClubName() {
        return clubName;
    }

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public String getCoachName() {
        return coachName;
    }

    public void setCoachName(String coachName) {
        this.coachName = coachName;
    }

    public int getLigue() {
        return ligue;
    }

    public void setLigue(int ligue) {
        this.ligue = ligue;
    }

    @Override
    public String toString() {
        return "Rival{" +
                "clubName='" + clubName + '\'' +
                ", teamName='" + teamName + '\'' +
                ", coachName='" + coachName + '\'' +
                ", ligue=" + ligue +
                '}';
    }
}
