package source;

public enum CoachClass{PZNPA, UEFAB, PZPNB, UEFAC}

