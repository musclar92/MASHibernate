package source;


import javax.persistence.*;
import java.io.*;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

/**
 * Created by Tomasz.ORZEL on 02.04.2017.
 */

enum MatchType {ligue, cup, control};

@Entity
public class Match{

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int matchId;
    private LocalDate dateOfTheMatch;
    private LocalTime matchHour;
    private int goalsScored = 0; //default
    private int goalsLost = 0; // default

    @ElementCollection
    private List<String> commentToMatch = new ArrayList<String>(); /// /opcjonalny, powtarzalny
    private MatchType matchType = MatchType.control;    //default
    private boolean homeOrAway = false; //false -- home, true --away

    @ManyToOne
    private Team team;

    @ManyToOne
    private Coach organizer;

    @ManyToOne
    private Rival opponent = null;

    @ManyToOne
    private Localization matchLoc;

    public Match() {
    }

    public Match(LocalDate dateOfTheMatch, MatchType matchType, boolean homeOrAway, Rival opponent) {
        this.dateOfTheMatch = dateOfTheMatch;
        this.matchType = matchType;
        this.homeOrAway = homeOrAway;
        this.opponent = opponent;
    }

    public Coach getOrganizer() {
        return organizer;
    }

    public void setOrganizer(Coach whoOrganize) {
        if(whoOrganize == null)
        {
            throw new RuntimeException("whoOrganize Can't be null");
        }else
        {
            removeOrganizer();
            this.organizer = whoOrganize;
        }
    }

    public void removeOrganizer()
    {
        if(organizer ==null)
        {
            System.out.println("There is no organizator!");
        }else
        {
            organizer.removeOrganizedMatch(this);
            organizer=null;
        }
    }

    public void setMatchLocalization(Localization matchLocalization) {
        if(this.homeOrAway==true)
        {
            System.out.println("You don't need book Loc - you will play away match");
        }else if(this.getDateOfTheMatch()== null || this.getMatchHour()== null || this.getTeam()== null)
        {
            new Exception("Date, hour and Team can't be null");

        }else if(matchLocalization.checkIsAvailable(this.dateOfTheMatch, this.getMatchHour()))
        {
            matchLocalization.addLocReservationForMatch(this.getDateOfTheMatch(),this.getMatchHour(),this.getTeam(),this);
            this.matchLoc = matchLocalization;
        }else
        {
            System.out.println("This date is already taken, chose anotherone!");
        }
    }


    public void changeOrganizer(Coach newOrganizer)
    {
        if(newOrganizer == null)
        {
            throw new RuntimeException("New Organizer can't be null");
        }else
        {
            if(organizer!=null){
                organizer.removeOrganizedMatch(this);
            }
            organizer = newOrganizer;
        }
    }


    public void endMatch(int goalsScored, int goalsLost)
    {
        this.goalsScored = goalsScored;
        this.goalsLost = goalsLost;
    }

    public void addComment(String newComment)
    {
        this.commentToMatch.add(newComment);

    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }

    public void getComments()
    {
        if(!this.commentToMatch.isEmpty())
        {
            for (int i = 0; i < this.commentToMatch.size(); i++)
            {
                System.out.println(commentToMatch.get(i));
            }
        }else
        {
            System.out.println("Brak komentarzy!");
        }
    }

    public String toString(){

        if(this.dateOfTheMatch.isAfter(LocalDate.now()))
        {
            return "Mecz zostanie rozegrany dnia: " + dateOfTheMatch  + " pomiedzy: Legia Warszawa, a " + opponent;
        }
        else
        {
            return "Match rozegrany dnia: " + dateOfTheMatch + " pomiedzy: Legia Warszawa, a " + opponent + " zakończony wynikiem " + goalsScored + " " + goalsLost;
        }
    }

    public int getMatchId() {
        return matchId;
    }

    public void setMatchId(int matchId) {
        this.matchId = matchId;
    }

    public void setDateOfTheMatch(LocalDate dateOfTheMatch) {
        this.dateOfTheMatch = dateOfTheMatch;
    }

    public LocalTime getMatchHour() {
        return matchHour;
    }

    public void setMatchHour(LocalTime matchHour) {
        this.matchHour = matchHour;
    }

    public void setGoalsScored(int goalsScored) {
        this.goalsScored = goalsScored;
    }

    public void setGoalsLost(int goalsLost) {
        this.goalsLost = goalsLost;
    }

    public void setCommentToMatch(List<String> commentToMatch) {
        this.commentToMatch = commentToMatch;
    }

    public MatchType getMatchType() {
        return matchType;
    }

    public void setMatchType(MatchType matchType) {
        this.matchType = matchType;
    }

    public boolean isHomeOrAway() {
        return homeOrAway;
    }

    public void setHomeOrAway(boolean homeOrAway) {
        this.homeOrAway = homeOrAway;
    }

    public void setOpponent(Rival opponent) {
        this.opponent = opponent;
    }

    public Localization getMatchLoc() {
        return matchLoc;
    }

    public void setMatchLoc(Localization matchLoc) {
        this.matchLoc = matchLoc;
    }

    /*
        Match getters
         */
    public Rival getOpponent()
    {
        return this.opponent;
    }
    public LocalDate getDateOfTheMatch(){
      return  this.dateOfTheMatch;
    }
    public int getGoalsScored()
    {
        return this.goalsScored;
    }
    public int getGoalsLost()
    {
        return this.goalsLost;
    }


    public List<String> getCommentToMatch(){
        return Collections.unmodifiableList(commentToMatch);
    }
}











