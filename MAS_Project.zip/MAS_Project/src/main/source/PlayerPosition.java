package source;
/**
 * @author Tomasz.ORZEL
 */

/**
 * Enum reprezentujacy mozliwe pozycje zawodnikow
 */

public enum PlayerPosition {
    GK  // Goalkeeper
    ,SW  // Sweeper
    ,RB  // Right Back (prawy obrońca)
    ,LB  // Left Back (lewy obrońca)
    ,CD  // Central Defence (obrońca)
    ,DM  // Defensive Midfield (defensywny pomocnik)
    ,LM  // Left Midfield (lewa pomoc)
    ,RM  // Right Midfield (prawa pomoc)
    ,AM  // Atacking Midfield (ofensywny pomocnik)
    ,RF  // Right Forward (prawy napad)
    ,LF  // Left Forward (lewy napad)
    ,ST  //  Striker (klasyczna 9 )
};