package source;

//import gui.*;

import DAO.PlayerManager;
import gui.MainForm;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

/**
 *
 * Main constructor
 */
public class Main {
    public JFrame frame, frame2;

    /**
     * Main startup method
     * @param args
     */

    public static void main(String[] args) {
        //new LogInForm();

        new MainForm("Tomek");

    }
}
