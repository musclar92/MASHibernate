package source;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.hibernate.cfg.Configuration;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Query;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Entity
public class Employee extends Person implements IEmployee{

    @OneToOne
    @Cascade(CascadeType.ALL)
    @NotFound(action = NotFoundAction.IGNORE)
    private Localization caresOf = null;
    private Double salary;
    private LocalDate employmentDate;
    private LocalDate contractTo = null;
    private LocalDate releaseDate = null;
    private static double riseMax = 3700.0;
    private String jobTitle;

    public Employee(int idPerson, String firstName, String lastName, LocalDate birthDate, String docNumber,
                    Double salary, LocalDate employmentDate, LocalDate contractTo, String jobTitle) {
        super(idPerson, firstName, lastName, birthDate, docNumber);
        this.salary = salary;
        this.employmentDate = employmentDate;
        this.contractTo = contractTo;
        this.jobTitle = jobTitle;
    }

    public Employee(String firstName, String lastName, LocalDate birthDate, String docNumber,
                    Double salary, LocalDate employmentDate, LocalDate contractTo, String jobTitle) {
        super(firstName, lastName, birthDate, docNumber);
        this.salary = salary;
        this.employmentDate = employmentDate;
        this.contractTo = contractTo;
        this.jobTitle = jobTitle;
    }

    public Employee() {}

    @Override
    public boolean isStillEmployee() {
        if(releaseDate == null)
        {
            return true;
        };

        return false;
    }

    @Override
    public void endContract(LocalDate endDate) {
        releaseDate = endDate;
    }

    @Override
    public void endContract() {
        releaseDate = LocalDate.now();
    }

    @Override
    public void addRaise(double howMany) {
        if(howMany <= riseMax)
        {
            salary += howMany;
        }else
        {
            throw new RuntimeException("Too high raise! Max rise is: "+ riseMax);
        }
    }


    public static void giveRaiseToAllEmployess(double howMany) //only for Employeess, not for Players
    {

        if(riseMax>=howMany)
        {

            //TODO - check error
            SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
            Session session = sessionFactory.openSession();
            session.beginTransaction();
            Query riseQuery = session.createQuery("update Employee set salary= salary + " + howMany);
            riseQuery.executeUpdate();
            session.getTransaction().commit();
            session.close();

        }else
        {
            throw new RuntimeException("To big raise");
        }


      //TODO when Employee will be added to Hibernate
    }

    public Localization getCaresOf() {
        return caresOf;
    }

    public void setCaresOf(Localization caresOf) {
        if(!caresOf.equals(null))
        {
            removeLoc();
        };
        this.caresOf = caresOf;
    }

    public void removeLoc()
    {
        if(caresOf.equals(null))
        {
            throw new RuntimeException("Employee don't care of any loc");
        }else
        {
            caresOf.removeKeeper();
            caresOf = null;
        }
    }


    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public LocalDate getEmploymentDate() {
        return employmentDate;
    }

    public void setEmploymentDate(LocalDate employmentDate) {
        this.employmentDate = employmentDate;
    }

    public LocalDate getContractTo() {
        return contractTo;
    }

    public void setContractTo(LocalDate contractTo) {
        this.contractTo = contractTo;
    }

    public LocalDate getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(LocalDate releaseDate) {
        this.releaseDate = releaseDate;
    }

    public static double getRiseMax() {
        return riseMax;
    }

    public void setRiseMax(double riseMax) {
        this.riseMax = riseMax;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

}
