package source;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


@Entity
public class Coach extends Employee{

    private CoachClass coachClass;
    private String license;

    @OneToMany(cascade = CascadeType.ALL)
    private List<Match> organizedMatches = new ArrayList<Match>();

    @ManyToOne(cascade = CascadeType.ALL)
    private Team trainsTeam;

    public Coach(){};

    public Coach(int idPerson, String firstName, String lastName, LocalDate birthdate, String docNumber, Double salary, LocalDate employmentdate,
            LocalDate contractTo, CoachClass coachClass, String license)
    {
        super(idPerson, firstName, lastName, birthdate, docNumber, salary, employmentdate, contractTo, "Coach" );
        this.coachClass = coachClass;
        this.license = license;
    }

    public Coach(String firstName, String lastName, LocalDate birthdate, String docNumber, Double salary, LocalDate employmentdate,
                 LocalDate contractTo, CoachClass coachClass, String license)
    {
        super(firstName, lastName, birthdate, docNumber, salary, employmentdate, contractTo, "Coach" );
        this.coachClass = coachClass;
        this.license = license;
    }


    public Team getTrainsTeam() {
        return trainsTeam;
    }

    public void setTrainsTeam(Team trainsTeam) {

        if(trainsTeam.getCurrentylyInTeam().contains(this))
        {
            System.out.println("Coach belong to this team! Can't train himself!");
        }else
        {
            this.trainsTeam = trainsTeam;
            trainsTeam.addCoachTeam(this);
        }


    }

    public void removeFromTeam() {
        if(trainsTeam.equals(null))
        {
            throw new RuntimeException("Trainer don't train any team");
        }else
        {
            trainsTeam.removeCoachTeam(this);
            setTrainsTeam(null);
        }

    }

    private void setCoachClass(CoachClass newClass)
    {
        this.coachClass = newClass;
    }

    public void setLicense(String license)
    {
        this.license = license;
    }

    public String getLicense()
    {
        return this.license;
    }

    public CoachClass getCoachClass()
    {
        return this.coachClass;
    }

    public List<Match> getOrganizedMatches() {
        return Collections.unmodifiableList(organizedMatches);
    }

    public void addOrganizedMatch(Match matchToAdd) {
        if(matchToAdd == null){
            throw new RuntimeException("Match can't be null");
        }else if(organizedMatches.contains(matchToAdd))
        {
            throw new RuntimeException("Match already organized by this Coach!");
        }else {
            organizedMatches.add(matchToAdd);
            matchToAdd.setOrganizer(this);
            //TODO add to DB
        }
        //this.organizedMatches.add(matchToAdd);
    }

    public void removeOrganizedMatch(Match matchToRemove)
    {
        if(matchToRemove == null)
        {
            throw new RuntimeException("Match can't be null");
        }else if(organizedMatches.size() <= 1)
        {
            throw new RuntimeException("Can't remove last Match");
        }else
        {
            organizedMatches.remove(matchToRemove);
        }
    }

}
