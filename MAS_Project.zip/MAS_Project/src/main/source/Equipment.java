package source;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import java.util.ArrayList;

//@Entity
public class Equipment {

   // @Id @GeneratedValue
    private int idEquipment;
    private String eqName;
    private String eqType;
    private byte ammount;
   // @ManyToMany
    private ArrayList<Person> assignPersons = new ArrayList<Person>();

   // private ArrayList<PersonEquip> personEquips = new ArrayList<PersonEquip>();

    public Equipment(){};

    Equipment(String eqName, String eqType, byte ammount)
    {
        this.eqName = eqName;
        this.eqType = eqType;
        this.ammount = ammount;
    }

    public ArrayList<Person> getAssignPersons() {
        return assignPersons;
    }

    public void setAssignPersons(ArrayList<Person> assignPersons) {
        this.assignPersons = assignPersons;
    }

    public int getIdEquipment() {
        return idEquipment;
    }

    public void setIdEquipment(int idEquipment) {
        this.idEquipment = idEquipment;
    }


    public byte getAmmount() {
        return ammount;
    }

    public String getEqName() {
        return eqName;
    }

    public String getEqType() {
        return eqType;
    }

    public void setEqName(String eqName) {
        this.eqName = eqName;
    }

    public void setEqType(String eqType) {
        this.eqType = eqType;
    }

    public void setAmmount(byte ammount) {
        this.ammount = ammount;
    }

/*
    public void removePersonEquip(PersonEquip personEquip) {
        if(personEquip.equals(null))
        {
            throw new RuntimeException("PersonEquip coan't be null");
        }else if(!personEquips.contains(personEquip))
        {
            throw new RuntimeException("PersonEquip don't assign to Equipment");
        }else
        {
            personEquips.remove(personEquip);
            personEquip.removeAssignetPerson();
        }
    }
    */
}
