package source;

import javax.persistence.*;
import javax.swing.text.DateFormatter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Localization {

    @Id @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int locId;
    private int size;
    private String locName;
    @Embedded
    private Address address;
    @OneToOne
    private Employee keeper;

    @OneToMany
    private Set<Training> trainingsList = new HashSet<Training>();

    @OneToMany
    private Set<Match> matchsList = new HashSet<Match>();

    //TODO zastanowic sie czy tutaj muszą być jakieś asocjacje
    private static HashMap<LocalDate, LocalizationReservation> locReservation = new HashMap<LocalDate, LocalizationReservation>();


    public Localization() {}

    public Localization(int size, String locName, Address address, Employee keeper) {
        this.size = size;
        this.locName = locName;
        this.address = address;
        this.keeper = keeper;
    }

    public Localization(int size, String locName) {
        this.size = size;
        this.locName = locName;
    }

    public Set<Training> getTrainingsList() {
        return trainingsList;
    }

    public void setTrainingsList(Set<Training> trainingsList) {
        this.trainingsList = trainingsList;
    }

    public Set<Match> getMatchsList() {
        return matchsList;
    }

    public void setMatchsList(Set<Match> matchsList) {
        this.matchsList = matchsList;
    }

    public int getLocId() {
        return locId;
    }

    public void setLocId(int locId) {
        this.locId = locId;
    }

    public Employee getKeeper() {
        return keeper;
    }

    public void setKeeper(Employee keeper) {
        this.keeper = keeper;
    }

    private void addReservation(LocalDate rezervationDate, LocalTime rezervationHour, Team team)
    {
        //SimpleDateFormat formatToRezervation = new SimpleDateFormat("yyyy-MM-dd");
        //String rezDate = formatToRezervation.format(rezervationDate);

        if(rezervationDate == null)
        {
            new Exception("Rezervation date can't be null");
        }else
        {
            if(locReservation.containsKey(rezervationDate))
            {
                if(locReservation.get(rezervationDate).checkIsAvailable(rezervationHour))
                {
                    locReservation.get(rezervationDate).assignRezervation(rezervationHour, team);
                }else
                {
                    System.out.println("This hour is already taken, chose anotherone");
                }
            }else
            {
                LocalizationReservation locRez = new LocalizationReservation(rezervationDate);
                locReservation.put(rezervationDate, locRez);
                locRez.assignRezervation(rezervationHour, team);
            }
        }
    }

    public void addLocReservationForMatch(LocalDate rezervationDate, LocalTime rezervationHour, Team team, Match match)
    {
        matchsList.add(match);      //TODO do zrobienia w obie strony   - zrobic addMatch
        addReservation(rezervationDate, rezervationHour, team);
    }

    public void addLocReservationForTraining(LocalDate rezervationDate, LocalTime rezervationHour, Team team, Training training)
    {
        trainingsList.add(training);    //TODO do zrobienia w obie strony - zrobic addTraining
        addReservation(rezervationDate, rezervationHour, team);
    }

    public boolean checkIsAvailable(LocalDate rezDate, LocalTime rezervationHour){
        if(locReservation.containsKey(rezDate)){
            if(locReservation.get(rezDate).checkIsAvailable(rezervationHour))
            {
                return true;
            }else
            {
                return false;
            }
        }else
        {
            return true;
        }
    }


    public void removeKeeper()
    {
        if(keeper.equals(null))
        {
            throw new RuntimeException("Loc don't have any keeper");
        }else{
            this.keeper = null;
            keeper.removeLoc();
        }

    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getLocName() {
        return locName;
    }

    public void setLocName(String locName) {
        this.locName = locName;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
}

@Embeddable
class Address{

    private String road;
    private String city;
    private String cityCode;

    public Address(String road, String city, String cityCode) {
        this.road = road;
        this.city = city;
        this.cityCode = cityCode;
    }

    public Address() {
    }

    public String getRoad() {
        return road;
    }

    public void setRoad(String road) {
        this.road = road;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

}