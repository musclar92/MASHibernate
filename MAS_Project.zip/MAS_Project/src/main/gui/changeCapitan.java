package gui;

import DAO.PlayerManager;
import DAO.TeamManager;
import source.Player;
import source.Team;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class changeCapitan {
    private JPanel changeCapitanMainJPanel;
    private JLabel changeCapitanLabel;
    private JComboBox changeCapitanComboBox;
    private JButton changeCapitanAcceptButton;
    private JButton changeCapitanCancelButton;
    private JPanel changeCapitanJPanel;
    private Container container = changeCapitanJPanel;
    public JFrame frame;
    /**
     * @author Tomasz.ORZEL
     */

    /**
     *
     * Konstruktor dla klasy changeCapitan, dzieku ktorej mozemy ustanowic nowego kapitana dla druzyny
     * @param teamId - id druzyny w ktorej mamy zmienic kapitana
     */
    public changeCapitan(int teamId)
    {
        frame = new JFrame("LoGoMon - change Capitan");
        frame.setContentPane(container);
        // frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        TeamManager teamManager = new TeamManager();
        PlayerManager playerDAO = new PlayerManager();
        List<Player> playerList = teamManager.playersInTeam(teamId);
        for(int i=0; i<playerList.size(); i++)
        {
            changeCapitanComboBox.addItem(playerList.get(i).getFirstName()+" "+playerList.get(i).getLastName());
        }

        Team team = teamManager.getTeamInfo(teamId);

        /**
         *
         * Listener przypisku "Przypisz"
         * W tym miejscu usuwamy starego kapitana i dodajemy nowego
         */

        changeCapitanAcceptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println(changeCapitanComboBox.getSelectedIndex()+1);
                teamManager.addNewCapitan(playerList.get(changeCapitanComboBox.getSelectedIndex()).getIdPerson(), teamId);
                frame.setVisible(false);
                showTeam showTeam = new showTeam(teamId);
            }
        });

        /**
         *
         * Listener dla przycisku "Anuluj"
         */
        changeCapitanCancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                showTeam showTeam = new showTeam(teamId);
            }
        });
    }
}
