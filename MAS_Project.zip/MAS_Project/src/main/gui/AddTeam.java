package gui;

import DAO.TeamManager;
import source.Team;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddTeam {
    private JPanel addTeamJPanel;
    private JPanel addTeamHeadJPanel;
    private JPanel addTeamTitleJPanel;
    private JLabel addTeamTitleLabel;
    private JLabel addTeamCapitanLabel;
    private JButton addTeamChangeCapitanButton;
    private JLabel addTeamshowPlayersLabel;
    private JLabel addTeamCoachLabel;
    private JButton addTeamAddPlayerButton;
    private JButton addTeamAddCoachButton;
    private JButton addTeamDeletePlayerButton;
    private JButton addTeamDeleteCoachButton;
    private JButton addTeamSaveButton;
    private JButton addTeamCancelButton;
    private JTextPane addTeamTitleTextPane;
    private JComboBox addTeamLigueComboBox;
    private JLabel addTeamLigueLabel;
    private Container container = addTeamJPanel;
    public JFrame frame;

    /**
     *
     * @author Tomasz.ORZEL
     */
    /**
     *
     * Konstruktor klasy AddTeam
     */
    public AddTeam()
    {
        TeamManager teamManager = new TeamManager();
        frame = new JFrame("LoGoMon - add Team");
        frame.setContentPane(container);
        // frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        for(int i=1; i<9; i++)
        {
            addTeamLigueComboBox.addItem(i);
        }

       // addTeamCapitanLabel.setText("Kapitan:");
       // addTeamCoachLabel.setText("Trenerzy");
       // addTeamshowPlayersLabel.setText("Zawodnicy");
        /**
         * Listener dla przycsku "Zapisz"
         * W tym miejscu tworzymy obiekt typu Team i dodajemy go do db
         */

        addTeamSaveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Team team = new Team(addTeamTitleTextPane.getText(),addTeamLigueComboBox.getSelectedIndex()+1);
                teamManager.addTeam(team);
                frame.setVisible(false);
                JOptionPane.showMessageDialog(addTeamJPanel, "Odśwież!", "Info",
                        JOptionPane.INFORMATION_MESSAGE);

            }
        });
        /**
         *
         * Listener dla przycisku "Anuluj"
         */
        addTeamCancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
            }
        });
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
