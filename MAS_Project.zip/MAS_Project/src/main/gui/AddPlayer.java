package gui;

import DAO.PlayerManager;
import source.Player;
import source.PlayerPosition;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class AddPlayer {
    private JPanel addPlayerJPanel;
    private JPanel addPlayerMainJPlanel;
    private JLabel addPlayerInfoLabel;
    private JLabel addPlayerFirstNameLabel;
    private JLabel addPlayerLastNameLabel;
    private JLabel addPlayerBirthDateLabel;
    private JLabel addPlayerDocNumberLabel;
    private JLabel addPlayerBetterLegLabel;
    private JLabel addPlayerSpeedLabel;
    private JLabel addPlayerTechniqueLabel;
    private JLabel addPlayerStrengthLabel;
    private JLabel addPlayerPositionLabel;
    private JTextPane addPlayerFirstNameTextPane;
    private JTextPane addPlayerLastNametextPane;
    private JTextPane addPlayerDocNumberTextPane;
    private JComboBox addPlayerBetterLegComboBox;
    private JSpinner addPlayerSpeedSpinner;
    private JSpinner addPlayerTechniqueSpinner;
    private JSpinner addPlayerStrengthSpinner;
    private JComboBox addPlayerPositionComboBox;
    private JButton addPlayerSaveButton;
    private JButton addPlayerExitButton;
    private JRadioButton addPlayerAdultRadioButton;
    private JLabel addPlayerPlayerTypeLabel;
    private JRadioButton addPlayerYouthRadioButton;
    private JFormattedTextField addPlayerBirthDateFormattedTextField;
    private Container container = addPlayerJPanel;
    public JFrame frame;

    public AddPlayer()
    {
        DateTimeFormatter dateFormatDay = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        PlayerManager playerManager = new PlayerManager();

        frame = new JFrame("LoGoMon - addPlayer");
        frame.setContentPane(container);
        // frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        addPlayerSpeedSpinner.setModel(new SpinnerNumberModel(50, 0, 100, 1));
        addPlayerTechniqueSpinner.setModel(new SpinnerNumberModel(50, 0, 100, 1));
        addPlayerStrengthSpinner.setModel(new SpinnerNumberModel(50, 0, 100, 1));


        addPlayerBetterLegComboBox.addItem("L");
        addPlayerBetterLegComboBox.addItem("R");

        addPlayerPositionComboBox.setModel(new DefaultComboBoxModel<>(PlayerPosition.values()));

        ButtonGroup playerTypeButtons = new ButtonGroup();

        playerTypeButtons.add(addPlayerAdultRadioButton);
        playerTypeButtons.add(addPlayerYouthRadioButton);


        addPlayerBirthDateFormattedTextField.setText("2000-01-01");

        /**
         * Listener dla przycisku "Zapisz"
         * W tym miejscu tworzymy obiekt typu Player i dodajemy go do DB.
         */
        addPlayerSaveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                Player player = new Player(addPlayerFirstNameTextPane.getText(),
                        addPlayerLastNametextPane.getText(),
                        LocalDate.parse(addPlayerBirthDateFormattedTextField.getText()),
                        addPlayerDocNumberTextPane.getText(),
                        checkLeg(),
                        (Integer) addPlayerSpeedSpinner.getValue(),
                        (Integer) addPlayerTechniqueSpinner.getValue(),
                        (Integer) addPlayerStrengthSpinner.getValue(),
                        PlayerPosition.values()[addPlayerPositionComboBox.getSelectedIndex()]);

               // player.setBirthDate(LocalDate.parse(addPlayerBirthDateFormattedTextField.getText()));

                System.out.println("Player imie: "+player.getFirstName()+" urodzony "+player.getBirthDate()+" a data w fieldzie to "+addPlayerBirthDateFormattedTextField.getText());
                playerManager.addPlayer(player);
                frame.setVisible(false);
                JOptionPane.showMessageDialog(addPlayerJPanel, "Odśwież widok!", "Info",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

        /**
         *
         * Listener dla przycisku "Wyjscie"
         */
        addPlayerExitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
            }
        });

    }

    private char checkLeg()
    {
        if(addPlayerBetterLegComboBox.getSelectedIndex()==0)
        {
            return 'R';
        }else
        {
            return 'L';
        }
    }
}
