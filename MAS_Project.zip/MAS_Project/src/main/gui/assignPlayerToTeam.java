package gui;

import DAO.PlayerManager;
import source.Player;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Tomasz.ORZEL
 */

public class assignPlayerToTeam {
    private JList <Player> assignPlayerToTeamList;
    private JLabel assignPlayerToTeamLabel;
    private JPanel assignPlayerToTeamJPanel;
    private JComboBox assignPlayerToTeamComboBox;
    private JButton assignPlayerToTeamAcceptButton;
    private JButton assignPlayerToTeamCancelButton;
    private JButton assignPlayerToTeam;
    private Container container = assignPlayerToTeamJPanel;
    public JFrame frame;

    /**
     *
     * Konstruktor dla klasy assignPlayerToTeam
     * @param teamId - id druzyny do ktorej mamy przypisac zawodnika
     */
    public assignPlayerToTeam(int teamId)
    {
        frame = new JFrame("LoGoMon -assignPlayerToTeam");
        frame.setContentPane(container);
        // frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        PlayerManager playerManager = new PlayerManager();
        List<Player> playerList = playerManager.getPlayersWithoutTeam();

        for(int i=0; i<playerList.size(); i++)
        {
            assignPlayerToTeamComboBox.addItem(playerList.get(i).getFirstName()+" "+playerList.get(i).getLastName());
        }

        /**
         *
         * Listener dla przycisku zapisu
         * W tym miejscu przypisujemy zawodnika do druzyny
         */
        assignPlayerToTeamAcceptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playerManager.addToTeam(playerList.get(assignPlayerToTeamComboBox.getSelectedIndex()), teamId);
                frame.setVisible(false);
                showTeam showTeam = new showTeam(teamId);

            }
        });
        /**
         *
         * Listener dla przycisku "Anuluj"
         */
        assignPlayerToTeamCancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                showTeam showTeam = new showTeam(teamId);
            }
        });
    }
}
