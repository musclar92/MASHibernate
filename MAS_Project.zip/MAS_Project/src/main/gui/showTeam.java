package gui;

import DAO.PlayerManager;
import DAO.TeamManager;
import source.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * @author Tomasz.ORZEL
 */

public class showTeam {
    private JTextPane showTeamCapitanJTextPanel;
    private JTable showTeamPlayersInTeamJTable;
    private JPanel showTeamHeadJPanel;
    private JPanel showTeamTitleJPanel;
    private JLabel showTeamTitleLabel;
    private JLabel showTeamCapitanLabel;
    private JPanel showTeamBodyJPanel;
    private JTable showTeamCoachTable;
    private JLabel showTeamshowPlayersLabel;
    private JLabel showTeamCoachLabel;
    private JPanel showTeamJPanel;
    private JScrollPane showTeamPlayerInTeamScrollPane;
    private JScrollPane showTeamCoachScrollPane;
    private JButton showTeamAddPlayerButton;
    private JButton showTeamAddCoachButton;
    private JButton showTeamChangeCapitanButton;
    private JButton showTeamDeletePlayerButton;
    private JButton showTeamDeleteCoachButton;
    private Container container = showTeamJPanel;
    public JFrame frame;

    /**
     *
     * Konstruktor dla klasy showTeam, pokazujacej nam informacje o wybranej druzynie
     * @param teamId, id druzyny ktora zostala wybrana
     */
    public showTeam(int teamId){
        frame = new JFrame("LoGoMon - show Team info");
        frame.setContentPane(container);
       // frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        showTeamCapitanLabel.setText("Kapitan:");
        showTeamCoachLabel.setText("Trenerzy");
        showTeamshowPlayersLabel.setText("Zawodnicy");


        TeamManager teamManager = new TeamManager();
        PlayerManager playerManager = new PlayerManager();
        List<Player> playersInTeam = teamManager.playersInTeam(teamId);
        showPlayersInTeam(teamId);

        Team t = teamManager.getTeamInfo(teamId);
        showTeamTitleLabel.setText(t.getLigueName());
        if(t.getCapitan()!=null)
        {
            showTeamCapitanJTextPanel.setText(t.getCapitan().getFirstName()+" "+ t.getCapitan().getLastName());
        }else
        {
            showTeamCapitanJTextPanel.setText("No capitan in team!");
        }


        /**
         * Listener dodawania trenera
         */
        showTeamAddCoachButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(showTeamJPanel, "Funkcjonalnosc w trakcie realizacji!!", "Info",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

        /**
         * Listener dodawania graczy do druzyny
         *
         */

        showTeamAddPlayerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(playerManager.countPlayersWithoutTeam()>0)
                {
                    assignPlayerToTeam apt = new assignPlayerToTeam(teamId);
                    frame.setVisible(false);
                }else
                {
                    JOptionPane.showMessageDialog(showTeamJPanel, "Brak wolnych zawodnikow!", "Info",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });


        /**
         * Listener zmiany kapitana druzyny
         */

        showTeamChangeCapitanButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(playersInTeam==null)
                {
                    JOptionPane.showMessageDialog(showTeamJPanel, "Najpierw przypisz zawodnikow do druzyny!", "Błąd",
                            JOptionPane.INFORMATION_MESSAGE);
                }else
                {
                    changeCapitan change = new changeCapitan(teamId);
                    frame.setVisible(false);
                }

            }
        });


        /**
         * Listener usuwania zawodnika z druzyny
         */

        showTeamDeletePlayerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int index = (int)showTeamPlayersInTeamJTable.getSelectedRow();
                if(index<0)
                {
                    JOptionPane.showMessageDialog(showTeamJPanel, "Najpierw wybierz z tabeli Players!", "Info",
                            JOptionPane.INFORMATION_MESSAGE);
                }else
                {
                        Integer valueOfId = (Integer) showTeamPlayersInTeamJTable.getValueAt(showTeamPlayersInTeamJTable.getSelectedRow(), 0);
                        System.out.println("Zaznaczylem zawodnika o id:"+playersInTeam.get(index).getIdPerson());
                        int dialogButton = JOptionPane.YES_NO_OPTION;
                        int dialogResult = JOptionPane.showConfirmDialog (null, "Czy na pewno mam usunać "+playersInTeam.get(index).getFirstName()+" "+playersInTeam.get(index).getLastName()+" z tej druzyny? ","Warning",dialogButton);
                        if(dialogResult == JOptionPane.YES_OPTION){
                            playerManager.removePlayerFromTeam(playersInTeam.get(index));
                            if(t.getCapitan().getIdPerson()==playersInTeam.get(index).getIdPerson())
                            {
                                System.out.println("No capitan in team");
                                showTeamCapitanJTextPanel.setText("No capitan in team!");
                            }
                            showPlayersInTeam(teamId);
                        }

                }
            }
        });


        /**
         *
         * Listener usuwajacy trenera z druzyny
         */
        showTeamDeleteCoachButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(showTeamJPanel, "Funkcjonalność w trakcie realizacji!", "Info",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
    };

    /**
     * Metoda pokazujaca wszytskich zawodnikow znajdujacych sie w druzynie
     * @param teamId - id druzyny dla ktorej chcemy wyswietlic zawodnikow
     */
    private void showPlayersInTeam(int teamId)
    {
        TeamManager teamManager = new TeamManager();
        PlayerManager playerManager = new PlayerManager();
        String [] colsPlayer = {"PlayerID", "Imie", "Nazwisko", "Stat"};
        DefaultTableModel model = new DefaultTableModel(colsPlayer, 0);
        showTeamPlayersInTeamJTable.setModel(model);
        List<Player> playersInTeam = teamManager.playersInTeam(teamId);
        if(playersInTeam!=null) {
            for (int i = 0; i < playersInTeam.size(); i++) {
                model.addRow(new Object[]{
                        playersInTeam.get(i).getIdPerson(),
                        playersInTeam.get(i).getFirstName(),
                        playersInTeam.get(i).getLastName(),
                        playersInTeam.get(i).countStat(),
                        playersInTeam.get(i).countStat(),
                });
            }
        }
        //showTeamCapitanJTextPanel.setText()
        //showTeamCapitanJTextPanel.setText(teamManager.getCapitanName(teamId));
    }
}


