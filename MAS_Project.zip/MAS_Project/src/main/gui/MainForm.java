package gui;
import DAO.PlayerManager;
import DAO.TeamManager;
import source.Player;
import source.Team;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.xml.crypto.Data;
import java.awt.*;
import java.awt.event.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * @author Tomasz.ORZEL
 */

public class MainForm {
    private JPanel HeadPanel;
    private JLabel LogedJLabel;
    private JButton logOutButton;
    private JButton exitButton;
    private JButton refreshButton;
    private JPanel BodyPanel;
    private JPanel MenuPanel;
    private JButton TeamsButton;
    private JButton EmployeeButton;
    private JButton MatchsButton;
    private JButton PlayersButton;
    private JButton TrainingsButton;
    private JButton PlacesButton;
    private JPanel DataField;
    private JTable DataTable;
    private JButton MainButton;
    private JPanel Panel;
    private JLabel LogedTextLabel;
    private JLabel MainTopicLabel;
    private JButton StuffButton;
    private JScrollPane DataTableScrollPane;
    private JButton MainDeleteButton;
    private JButton FuncionalButton;
    private Container container = Panel;


    private MainForm this_;

    private List<Team> teamList;
    private List<Player> playerList;
    DateTimeFormatter dateFormatDay = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    DateTimeFormatter dateFormatHour = DateTimeFormatter.ofPattern("HH:mm");

    JPopupMenu popupMenu = new JPopupMenu();
    private static String INSERT_CMD = "Dodaj";
    private static String EDIT_CMD = "Edytuj";
    JMenuItem menuItem = new JMenuItem(INSERT_CMD);

    private char status;

    PlayerManager playerManager = new PlayerManager();
    TeamManager teamManager = new TeamManager();

    JFrame frame;
    String coach = "trener", coachToTeam = "trenuje",                   //dot. trener-druzyna
            boss = "przelozony", emp = "pracownik",                    //dot. przelozony-pracownik
            belongsTo = "jest w", isIn = "nalezy";                    //dot. druzyna - zawodnik

    String teamButtonText = "Dodaj Druzynę", playersButtonText = "Dodaj Zawodnika", matchsButtonText = "Dodaj Mecz",
            employeeButtonText = "Dodaj Pracownika", placesButtonText = "Dodaj Miejsce", stuffButtonText = "Dodaj sprzęt";

    String teamDelButtonText = "Usuń Druzynę", playersDelButtonText = "Usuń Zawodnika", matchsDelButtonText = "Usuń Mecz",
            employeeDelButtonText = "Usuń Pracownika", placesDelButtonText = "Usuń Miejsce", stuffDelButtonText = "Usuń sprzęt";

    /**
     * Konstruktor dla głownego okna programu, przyjmujacy jako parametr nazwe uzytkownika ktory jest zalogowany
     * @param user
     */
    public MainForm(String user) {

        this_ = this;
        frame = new JFrame("LoGoMon - Main Panel");


        DataTable = new JTable() {

            public boolean isCellEditable(int data,int column)
            {
                return false;
            };


            /*public String getToolTipText(MouseEvent e) {
                String tooltip = null;
                java.awt.Point p = e.getPoint();
                int index = rowAtPoint(p);
                try {
                    if (index >= 0) {
                        tooltip = makeToolTip(index);
                    }
                } catch (RuntimeException ex) {
                }
                return tooltip;
            } */
        };

        DataTableScrollPane.setViewportView(DataTable);

        LogedTextLabel.setText(user);
        frame.setContentPane(container);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        MainDeleteButton.setVisible(false);

       // popupMenu.add(menuItem);


        /**
         * Listener dla przycisku "druzyny", w glownej tabeli pojawia sie nam wszystkie druzyny zapisane w naszym programie
         */

        TeamsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                showTeams();
            }
        });


        /**
         *
         * Listener dla przycisku "Zawodnicy", w głownej tabeli pojawia sie nam wszyscy zawodnicy zapisani w naszym programie
         */

        PlayersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.out.println("Players list");
                showPlayer();
            }
        });


        /**
         * Listener dla tablicy, reagujacy na podwonje klikniecie myszy
         */


        DataTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if(e.getClickCount() == 2 && e.getButton() == MouseEvent.BUTTON1) {
                    super.mouseClicked(e);
                    if(MainButton.getText().equals(teamButtonText))
                    {
                        int index = (int)DataTable.getSelectedRow();
                        Integer valueOfId = (Integer) DataTable.getValueAt(DataTable.getSelectedRow(), 0);
                        TableModel dataTableModel = DataTable.getModel();

                        System.out.println(valueOfId);
                        showTeam showteam = new showTeam(valueOfId);

                    }else if(MainButton.getText().equals(playersButtonText))
                    {
                        int index = (int)DataTable.getSelectedRow();
                        Integer valueOfId = (Integer) DataTable.getValueAt(DataTable.getSelectedRow(), 0);
                        TableModel dataTableModel = DataTable.getModel();

                       // System.out.println(valueOfId);
                        editPlayer editPlayer = new editPlayer(valueOfId);

                    }
                }else if(e.getButton() == MouseEvent.BUTTON3)
                {
                    super.mouseClicked(e);

                    int index = (int)DataTable.getSelectedRow();
                    Integer valueOfId = (Integer) DataTable.getValueAt(DataTable.getSelectedRow(), 0);
                    valueOfId = DataTable.getSelectedRow();
                    System.out.println(DataTable.getSelectedRow());
                    if(MainButton.getText().equals(teamButtonText))
                    {
                        PopoupMenu pop = new PopoupMenu(DataTable, teamList.get(valueOfId));
                        pop.show(e.getComponent(), e.getX(), e.getY());

                    }else if(MainButton.getText().equals(playersButtonText))
                    {
                        PopoupMenu pop = new PopoupMenu(DataTable, playerList.get(valueOfId));
                        pop.show(e.getComponent(), e.getX(), e.getY());

                    }
                };
            }
        });

        /**
         * listener dla przycisku "Wyjscie"
         */
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(Panel, "Bye !", "Info",
                        JOptionPane.INFORMATION_MESSAGE);
                System.exit(1);
            }
        });

        /**
         * Listener dla przycisku "Odswiez", odswieza aktualny widok tabeli
         */

        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(MainButton.getText().equals(teamButtonText))
                {
                    showTeams();
                }else if(MainButton.getText().equals(playersButtonText))
                {
                    showPlayer();
                }else
                {
                    //TODO
                };
            }
        });


        /**
         * Listener dla przycisku "Wyloguj",
         */
        logOutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(Panel, "Funkcjonalność w realizacji!", "Info",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

        /**
         * Listener dla glownego przycisku funkcyjnego, dzieki niemu mozemy dodac zawodnika, druzyne, itd
         */
        MainButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(MainButton.getText().equals(playersButtonText))
                {
                    AddPlayer addPlayer = new AddPlayer();
                }else if(MainButton.getText().equals(teamButtonText))
                {
                    AddTeam addTeam = new AddTeam();
                }else
                {
                    //TODO for else
                }
            }
        });


        /**
         * Listener dla glownego przycisku funkcyjnego w postaci delete. Dzieki niemu mozemy usunać drużyne, zawodnika, itd
         */

        MainDeleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int index = (int)DataTable.getSelectedRow();
                if(index<0)
                {
                    JOptionPane.showMessageDialog(Panel, "Najpierw wybierz z tabeli!", "Info",
                            JOptionPane.INFORMATION_MESSAGE);
                }else
                {
                    if(MainDeleteButton.getText().equals(playersDelButtonText))
                    {

                        Integer valueOfId = (Integer) DataTable.getValueAt(DataTable.getSelectedRow(), 0);
                        System.out.println("Zaznaczylem zawodnika o id:"+playerList.get(index).getIdPerson());
                        int dialogButton = JOptionPane.YES_NO_OPTION;
                        int dialogResult = JOptionPane.showConfirmDialog (null, "Czy na pewno mam usunać "+playerList.get(index).getFirstName()+" "+playerList.get(index).getLastName()+"? ","Warning",dialogButton);
                        if(dialogResult == JOptionPane.YES_OPTION){
                           // teamDAO.removeFromCapitan(playerList.get(index));
                            teamManager.removePlayer(playerList.get(index).getIdPerson());
                        }

                    }else if(MainDeleteButton.getText().equals(teamDelButtonText))
                    {
                        int dialogButton = JOptionPane.YES_NO_OPTION;
                        int dialogResult = JOptionPane.showConfirmDialog (null, "Czy na pewno mam usunać "+teamList.get(index).getLigueName()+"? ","Warning",dialogButton);
                        if(dialogResult == JOptionPane.YES_OPTION){
                //        playerDAO.removeAllPlayerFromTeam(teamList.get(index));
                //        teamDAO.removeTeam(teamList.get(index));
                        }
                    }else
                    {

                    }
                }
            }
        });


    }

    /**
     * Metoda tworzaca GUI.
     */
    private void createUIComponents() {
        // TODO: place custom component creation code here
    }

    public static void main(String[] args) {

    }

    /**
     * Metoda pokazujaca wszystkich zawodnikow w glownej tabeli
     */

    private void showPlayer()
    {
        System.out.println("Players Button");
        // checkPlayers();

        playerList = playerManager.getAllPlayers();
        MainButton.setText(playersButtonText);
        MainDeleteButton.setVisible(false);
       // MainDeleteButton.setText(playersDelButtonText);
        MainTopicLabel.setText("Wszystkie drużyny: ");
        String [] cols = {"IDPerson", "Imie", "Nazwisko", "Data Urodzenia", "Numer dokumentu",
                "Lepsza noga", "Szybkosci", "Technika", "Sila", "Pozycja", "Stat"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        DataTable.setRowSelectionAllowed(true);
        DataTable.setModel(model);
        if(playerList!=null) {
            for (int i = 0; i < playerList.size(); i++) {
                model.addRow(new Object[]{
                        playerList.get(i).getIdPerson(),
                        playerList.get(i).getFirstName(),
                        playerList.get(i).getLastName(),
                        playerList.get(i).getBirthDate(),
                        playerList.get(i).getDocNumber(),
                        playerList.get(i).getBetterLeg(),
                        playerList.get(i).getSpeed(),
                        playerList.get(i).getTechnique(),
                        playerList.get(i).getStrength(),
                        playerList.get(i).getPosition(),
                        playerList.get(i).countStat()
                });
            }
        }
    };

    /**
     * Metoda pokazujaca wszystkie druzyny w glownej tabeli
     */


    private void showTeams(){
        System.out.println("Teams Button");
        teamList = teamManager.getAllTeams();
        MainButton.setText(teamButtonText);
        MainDeleteButton.setText(teamDelButtonText);
        MainTopicLabel.setText("Wszystkie drużyny: ");
        String [] cols = {"TeamId", "Liguename", "Ligue"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        DataTable.setModel(model);
        if(teamList!=null) {
            for (int i = 0; i < teamList.size(); i++) {
                model.addRow(new Object[]{
                        teamList.get(i).getTeamID(),
                        teamList.get(i).showLigueName(),
                        teamList.get(i).getLigue()
                });
            }
        }
    };

    private static String roleNameEmployee = "roleEmployee";
    private static String roleNamePlayer = "rolePlayer";
}

class PopoupMenu extends JPopupMenu
{

    JMenuItem add=new JMenuItem("Dodaj");
    JMenuItem edit=new JMenuItem("Edytuj");

    public PopoupMenu(JTable table, Player player)
    {
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               // JOptionPane.showMessageDialog(add,"DODANY");
                AddPlayer addPlayer = new AddPlayer();
            }
        });

        edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               // JOptionPane.showMessageDialog(add,"Funkcjonalnosc w trakcie realizacji!");
                editPlayer editPlayer = new editPlayer(player.getIdPerson());
            }
        });

        this.add(add);
        this.add(edit);
    }

    public PopoupMenu(JTable table, Team team)
    {
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // JOptionPane.showMessageDialog(add,"DODANY");
                AddTeam addTeam = new AddTeam();
            }
        });

        edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //JOptionPane.showMessageDialog(add,"Funkcjonalnosc w trakcie realizacji!");
                showTeam showTeam = new showTeam(team.getTeamID());

            }
        });

        this.add(add);
        this.add(edit);
    }

}
