package gui;

import DAO.PlayerManager;
import source.Player;
import source.PlayerPosition;

import javax.swing.*;
import javax.swing.text.DateFormatter;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class editPlayer {
    private JPanel editPlayerJLabel;
    private JLabel editPlayerInfoLabel;
    private JTextPane editPlayerFirstNameTextPane;
    private JTextPane editPlayerLastNametextPane;
    private JTextPane editPlayerBirthDateTextPane;
    private JTextPane editPlayerDocNumberTextPane;
    private JComboBox editPlayerBetterLegComboBox;
    private JSpinner editPlayerSpeedSpinner;
    private JSpinner editPlayerTechniqueSpinner;
    private JSpinner editPlayerStrengthSpinner;
    private JComboBox editPlayerPositionComboBox;
    private JButton editPlayerSaveButton;
    private JButton editPlayerExitButton;
    private JLabel editPlayerFirstNameLabel;
    private JLabel editPlayerLastNameLabel;
    private JLabel editPlayerBirthDateLabel;
    private JLabel editPlayerDocNumberLabel;
    private JLabel editPlayerBetterLegLabel;
    private JLabel editPlayerSpeedLabel;
    private JLabel editPlayerTechniqueLabel;
    private JLabel editPlayerStrengthLabel;
    private JLabel editPlayerPositionLabel;
    private JFormattedTextField editPlayerBirthDateFormattedTextField;
    private Container container = editPlayerJLabel;
    public JFrame frame;
    /**
     * @author Tomasz.ORZEL
     */

    /**
     * Konstruktor klasy editPlayer, umożliwiajacy edycje wybranego zawodnika
     * @param playerId
     */

    public editPlayer(int playerId)
    {
        DateTimeFormatter dateFormatDay = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        PlayerManager playerManager = new PlayerManager();
        Player player = playerManager.getPlayer(playerId);

        frame = new JFrame("LoGoMon - show Team info");
        frame.setContentPane(container);
        // frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);


        editPlayerFirstNameTextPane.setText(player.getFirstName());
        editPlayerLastNametextPane.setText(player.getLastName());

        editPlayerBirthDateFormattedTextField.setText(String.valueOf((player.getBirthDate())));


        editPlayerDocNumberTextPane.setText(player.getDocNumber());

        editPlayerSpeedSpinner.setModel(new SpinnerNumberModel(player.getSpeed(), 0, 100, 1));
        editPlayerTechniqueSpinner.setModel(new SpinnerNumberModel(player.getTechnique(), 0, 100, 1));
        editPlayerStrengthSpinner.setModel(new SpinnerNumberModel(player.getStrength(), 0, 100, 1));

        editPlayerBetterLegComboBox.addItem("L");
        editPlayerBetterLegComboBox.addItem("R");

        if(player.getBetterLeg()=='R')
        {
            editPlayerBetterLegComboBox.setSelectedIndex(1);
        }else
        {
            editPlayerBetterLegComboBox.setSelectedIndex(0);
        }

        editPlayerPositionComboBox.setModel(new DefaultComboBoxModel<>(PlayerPosition.values()));
        editPlayerPositionComboBox.setSelectedItem(player.getPosition());
        /**
         * Listener dla przycisku "Zapisz"
         * W tym miejscu zbieramy dane które były podane edycji i aktualizujemy je w db
         */
        editPlayerSaveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                char playerLeg;
                if(editPlayerBetterLegComboBox.getSelectedIndex()==1)
                {
                    playerLeg = 'R';
                }else
                {
                    playerLeg = 'L';
                }
                playerManager.updatePlayer(player.getIdPerson(),
                        editPlayerFirstNameTextPane.getText(),
                        editPlayerLastNametextPane.getText(),
                        LocalDate.parse(editPlayerBirthDateFormattedTextField.getText()),
                        editPlayerDocNumberTextPane.getText(),
                        playerLeg,
                        (Integer) editPlayerSpeedSpinner.getValue(),
                        (Integer) editPlayerTechniqueSpinner.getValue(),
                        (Integer) editPlayerStrengthSpinner.getValue(),
                        editPlayerPositionComboBox.getSelectedIndex());
                frame.setVisible(false);
                JOptionPane.showMessageDialog(editPlayerJLabel, "Odśwież widok!", "Info",
                        JOptionPane.INFORMATION_MESSAGE);

            }
        });
        /**
         *
         * Listener dla przycisku "Anuluj"
         */
        editPlayerExitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
            }
        });

    }
}
