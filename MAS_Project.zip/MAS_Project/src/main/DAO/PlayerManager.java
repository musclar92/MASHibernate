package DAO;

import source.Person;
import source.Player;
import source.PlayerPosition;
import source.Team;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class PlayerManager {

    public PlayerManager() {
    }

    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myDatabasePersistence");

    public List<Player> getAllPlayers(){
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myDatabasePersistence");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        List<Player> playerList;
        entityManager.getTransaction().begin();
        System.out.println("Wczytuje z db");
        playerList = entityManager.createQuery("SELECT p FROM Player p").getResultList();
        entityManager.close();
        if(playerList.size()>0)
        {
            return playerList;
        }else
        {
            return null;
        }
    }

    public void addPlayer(Player player)
    {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.persist(player);
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    public Player getPlayer(int playerID)
    {
        Player player;
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        player = entityManager.find(Player.class, playerID);
        entityManager.getTransaction().commit();
        entityManager.close();

        return player;
    }

    public void updatePlayer(int playerId, String firstName, String lastName, LocalDate birthDate, String docNumber, char betterLeg, int speed, int technique, int strength, int positionIndex )
    {

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        Player player = entityManager.find(Player.class, playerId);
        player.setFirstName(firstName);
        player.setLastName(lastName);
        player.setBirthDate(birthDate);
        player.setDocNumber(docNumber);
        player.setBetterLeg(betterLeg);
        player.setSpeed(speed);
        player.setTechnique(technique);
        player.setStrength(strength);
        player.setPosition(PlayerPosition.values()[positionIndex]);

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    public int countPlayersWithoutTeam() {
        List<Player> playersCount = this.getPlayersWithoutTeam();
        if (playersCount == null) {
            return 0;
        } else {
            return playersCount.size();
        }
    }

    public List<Player> getPlayersWithoutTeam(){
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        List<Player> players = entityManager.createQuery("SELECT p FROM Player p WHERE p.currentlyTeam = null").getResultList();
        entityManager.getTransaction().commit();
        entityManager.close();
        return players;
    }

    public void addToTeam(Player player, int team)
    {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        Player playerToUpdate = entityManager.find(Player.class, player.getIdPerson());
        Team teamToUpdate = entityManager.find(Team.class, team);

        playerToUpdate.setPlayerInTeam(teamToUpdate);

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    public void removePlayerFromTeam(Player player)
    {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        Player playerToRemove = entityManager.find(Player.class, player.getIdPerson());
        playerToRemove.removePlayerInTeam();

        entityManager.getTransaction().commit();
        entityManager.close();

    }
}
