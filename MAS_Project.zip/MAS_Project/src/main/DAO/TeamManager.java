package DAO;

import org.hibernate.annotations.Where;
import source.Player;
import source.Team;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

public class TeamManager {

    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("myDatabasePersistence");


    public TeamManager() {
    }
    public List<Team> getAllTeams(){

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        List<Team> teamList;
        entityManager.getTransaction().begin();
        System.out.println("Wczytuje z db");
        teamList = entityManager.createQuery("SELECT p FROM Team p").getResultList();
        entityManager.close();
        if(teamList.size()>0)
        {
            return teamList;
        }else
        {
            return null;
        }
    }

    public void addTeam(Team team)
    {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.persist(team);
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    public void removeTeam(Team team)
    {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.remove(team);
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    public List<Player> playersInTeam(int teamID)
    {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        List<Player> playersInTeamList = entityManager.createQuery("SELECT p FROM Player p WHERE p.currentlyTeam = "+teamID).getResultList();
        entityManager.getTransaction().commit();
        entityManager.close();

        return playersInTeamList;
    }

    public Team getTeamInfo(int teamId)
    {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        Team team = entityManager.find(Team.class, teamId);
        entityManager.getTransaction().commit();
        entityManager.close();
        return team;
    }

    public void addNewCapitan(int playerId, int teamId)
    {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        Player player = entityManager.find(Player.class, playerId);
        Team team = entityManager.find(Team.class, teamId);
        team.setNewCapitan(player);

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    public void removePlayer(int playerId)
    {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        Player player = entityManager.find(Player.class, playerId);
        player.removePlayerInTeam();

        entityManager.remove(player);

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
